const http = require("http");
const port = 8081;

const welcomeHandler = (req, res) => {
  res.setHeader("Content-Type", "text/plain");
  res.statusCode = 200;
  res.end("Welcome to Dominos!");
};

const contactHandler = (req, res) => {
  res.setHeader("Content-Type", "application/json");
  res.statusCode = 200;
  res.end(JSON.stringify({
    phone: "18602100000",
    email: "guestcaredominos@jublfood.com"
  }));
};

const server = http.createServer((req, res) => {
  const path = req.url;

  if (path === "/welcome") {
    welcomeHandler(req, res);
  } else if (path === "/contact") {
    contactHandler(req, res);
  } else {
    res.statusCode = 404;
    res.end("Not found");
  }
});

server.listen(port, () => {
  console.log(`Server started on port ${port}`);
});